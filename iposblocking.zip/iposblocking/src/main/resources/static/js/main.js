$(document).ready(function () {

  $("#option1").prop("checked", true);

  $("#contractCode").prop("disabled", true);
  $("#componentCode").prop("disabled", true);
  $("#promotionCode").prop("disabled", true);

  $("#option2").click(function () {
    $("#contractCode").prop("disabled", false);
    $("#componentCode").prop("disabled", false);
    $("#promotionCode").prop("disabled", false);
  });
});

$(function () {
  $("#blockingDate").datepicker({dateFormat: "yy-mm-dd"});
});