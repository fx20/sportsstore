package com.fx.rnd.iposblocking.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IposBlockingRequest {

  private String blockingName;
  private String blockingDate;
  private String platform;
  private String version;
  private Boolean blockingAllProduct;
  private String contractCode;
  private String componentCode;
  private String promotionCode;

}
