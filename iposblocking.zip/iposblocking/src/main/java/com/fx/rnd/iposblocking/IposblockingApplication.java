package com.fx.rnd.iposblocking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IposblockingApplication {

  public static void main(String[] args) {
    SpringApplication.run(IposblockingApplication.class, args);
  }

}
