package com.fx.rnd.iposblocking.repository;

import com.fx.rnd.iposblocking.model.IposBlockingModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IposBlockingRepo extends JpaRepository<IposBlockingModel, String> {

}
