package com.fx.rnd.iposblocking.controller;

import com.fx.rnd.iposblocking.model.IposBlockingModel;
import com.fx.rnd.iposblocking.model.IposBlockingRequest;
import com.fx.rnd.iposblocking.model.IposBlockingResponse;
import com.fx.rnd.iposblocking.repository.IposBlockingRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class IposBlockingController {

  private final IposBlockingRepo iposBlockingRepo;
  Logger logger = LoggerFactory.getLogger(IposBlockingController.class);

  public IposBlockingController(IposBlockingRepo iposBlockingRepo) {
    this.iposBlockingRepo = iposBlockingRepo;
  }

  @GetMapping("/")
  public String callIndex(Model theModel) {
    IposBlockingRequest blockingRequest = new IposBlockingRequest();
    theModel.addAttribute("iposBlockingRequest", blockingRequest);
    return "blocking-form";
  }

  @PostMapping("/save")
  public String saveData(
      @ModelAttribute("iposBlockingRequest") IposBlockingRequest blockingRequest) {
    logger.warn(blockingRequest.toString());
    String rules = generateRules(blockingRequest);
    logger.warn(rules);
    IposBlockingModel model = new IposBlockingModel();
    model.setDescription(blockingRequest.getBlockingName());
    model.setRule(rules);
    model.setContext("policy");
    model.setSeq(1);
    model.setStatus("A");
    iposBlockingRepo.save(model);

    IposBlockingResponse response = new IposBlockingResponse();
    response.setCode(String.valueOf(HttpStatus.OK.value()));
    response.setStatus(HttpStatus.OK.getReasonPhrase());
    response.setBlockingConfiguration("rules");
//    return response;
    return "redirect:/";
  }

  private String generateRules(IposBlockingRequest blockingRequest) {
    StringBuilder sb = new StringBuilder();
    sb.append("{\"logical\":{\"method\":\"and\",\"logics\":[");
    if (blockingRequest.getPlatform() != null) {
      sb
          .append("{\"method\":\"in\",")
          .append("\"field\":\"platform\",")
          .append("\"param\":[\"")
          .append(blockingRequest.getPlatform().replace(",","\",\""))
          .append("\"]},");
    }
    if (blockingRequest.getVersion() != null) {
      int majorVer = Integer.parseInt(blockingRequest.getVersion()
          .substring(0, blockingRequest.getVersion().indexOf(".")));
      String minorVer = blockingRequest.getVersion()
          .substring(blockingRequest.getVersion().indexOf(".") + 1);
      sb
          .append("{\"method\":\"sqsRegEx\",")
          .append("\"param\":[")
          .append("\"[1-")
          .append(majorVer - 1)
          .append("\\\\..*|")
          .append(majorVer)
          .append("\\\\.[0-")
          .append(minorVer.charAt(0))
          .append("][0-")
          .append(minorVer.charAt(1))
          .append("].*\"]},");
    }
    if (blockingRequest.getBlockingDate() != null) {
      sb
          .append("{\"method\":\"effTime\",")
          .append("\"startTime\":\"")
          .append(blockingRequest.getBlockingDate())
          .append(" 23:59:00\"}]");
    }
    sb
        .append("]},\"msg\":\"Selected plan(s) cannot be submitted. ")
        .append("Please redo in the latest version and resubmit.");
    return sb.toString();
  }

}
