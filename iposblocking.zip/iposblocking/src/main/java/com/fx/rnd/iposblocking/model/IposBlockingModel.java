package com.fx.rnd.iposblocking.model;

import com.sun.istack.NotNull;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenericGenerator;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "T_SubRule")
public class IposBlockingModel {

  @Id
  @NotNull
  @GeneratedValue(generator = "uuid")
  @GenericGenerator(name = "uuid", strategy = "uuid2")
  @Column(name = "id", length = 40, nullable = false)
  private String id;

  @NotNull
  @Size(max = 100)
  @Column(name = "description", length = 100, nullable = false)
  private String Description;

  @NotNull
  @Size(max = 1000)
  @Column(name = "rule", length = 1000, nullable = false)
  private String Rule;

  @NotNull
  @Size(max = 10)
  @Column(name = "context", length = 10, nullable = false)
  private String Context;

  @NotNull
  @Size(max = 10)
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "seq", length = 10, nullable = false)
  private Integer Seq;

  @NotNull
  @Size(max = 1)
  @Column(name = "status", length = 1, nullable = false)
  private String Status;

}
